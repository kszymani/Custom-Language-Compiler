/*
 * Kod maszyny wirtualnej do projektu z JFTT2020
 *
 * Autor: Maciek Gębala
 * http://ki.pwr.edu.pl/gebala/
 * 2020-11-12
*/

Narzędzia:
----------------------------------------
bison (GNU Bison) 3.5.1
flex 2.6.4
GNU Make 4.2.1
g++ 9.3.0

libcln-dev 1.3.6

Pliki:
----------------------------------------
ReadMe.txt
Makefile
colors.hh
instructions.hh
lexer.l
parser.y
mw.cc
mw-cln.cc
main.cc
