#pragma once

enum Instructions : int { GET, PUT, LOAD, STORE, ADD, SUB, RESET, INC, DEC, SHR, SHL, JUMP, JZERO, JODD, HALT };
